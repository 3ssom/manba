#!/bin/bash

_defaultdatabaseName='manba'
_defaultdatabaseUsername='root'
_defaultdatabasePassword='root'
_defaultdatabaseHost='localhost'
_defaultdatabasePort='8889'

. scripts/color.sh

echo -e " ${BIYellow} ██ Pro tip! running this script again will drop the database and will install the project again ${Reset}"
sleep 2
_execute()
{
# Confirm the execution
DEFAULT="n"
echo -e "Do you want to complete the installation? (y/n) ${BIGreen} [Default : n] ${Reset}"
read CONFIRM
CONFIRM="${CONFIRM:-${DEFAULT}}"
if [[ $CONFIRM == "y" || $CONFIRM == "Y" || $CONFIRM == "yes" || $CONFIRM == "Yes" ]]
then
  echo -e "${BWhite}Here we go .... ${Reset}"
  sleep 2
  mkdir -p private
  echo -e "${BIGreen}\xE2\x9C\x94 Private folder created successfully"
  sleep 1
  mkdir -p temp
  echo -e "\xE2\x9C\x94 temp folder created successfully  ${Reset}"
  sleep 1
  sh -c "echo '<?php\n\n' > web/sites/default/settings.local.php"
  composer install --no-interaction
  echo -e "Enter the database name ${BIGreen} [Default : $_defaultdatabaseName] ${Reset} :"
  read _databaseName
  _databaseName="${_databaseName:-${_defaultdatabaseName}}"
  echo -e "Enter the database username ${BIGreen} [Default : $_defaultdatabaseUsername]${Reset} : "
  read _databaseUsername
  _databaseUsername="${_databaseUsername:-${_defaultdatabaseUsername}}"
  echo -e "Enter the database password ${BIGreen} [Default : $_defaultdatabasePassword]${Reset} : "
  read _databasePassword
  _databasePassword="${_databasePassword:-${_defaultdatabasePassword}}"
  echo -e "Enter the database host ${BIGreen} [Default : $_defaultdatabaseHost]${Reset} : "
  read _databaseHost
  _databaseHost="${_databaseHost:-${_defaultdatabaseHost}}"
  echo -e "Enter the database port ${BIGreen} [Default : $_defaultdatabasePort]${Reset} : "
  read _databasePort
  _databasePort="${_databasePort:-${_defaultdatabasePort}}"
  sleep 1
  echo -e "${BWhite}Your Databse info is: $_databaseUsername:$_databasePassword@$_databaseHost:$_databasePort/$_databaseName ${Reset}"
  sleep 1
  vendor/bin/drush si standard --db-url=mysql://$_databaseUsername:$_databasePassword@$_databaseHost:$_databasePort/$_databaseName --site-name=automated -y --account-pass=admin -y
  vendor/bin/drush entity:delete shortcut_set
  vendor/bin/drush cset system.site uuid 690a5463-59f2-4f05-8e0c-a18f8b050b69 -y
  chmod 777 web/sites/default
  mkdir -p web/sites/default/files
  echo -e "${BIGreen} \xE2\x9C\x94 Installation completed successfully ${Reset}"
  sleep 1
  echo -e " ${BIPurple} ████ Prepare settings.local.php file ████ ${Reset}"
  sleep 1
  echo -e '<?php\n\n//phpcs:ignoreFile\n\n$settings['\''hash_salt'\''] = '\''3kUsQNSUTYK_qf3Ki4nWw8gU4xHxByMuuLVdiw56ByfPe5rVhbAgFef7aYFzz5tZDUF28xIGBg'\'';\n\n$databases['\''default'\'']['\''default'\''] = array (\n  '\''database'\'' => '\'$_databaseName\'',\n  '\''username'\'' => '\'$_databaseUsername\'',\n  '\''password'\'' => '\'$_databasePassword\'',\n  '\''prefix'\'' => '\'''\'',\n  '\''host'\'' => '\'$_databaseHost\'',\n  '\''port'\'' => '\'$_databasePort\'',\n  '\''namespace'\'' => '\''Drupal\\Core\\Database\\Driver\\mysql'\'',\n  '\''driver'\'' => '\''mysql'\'',\n);' > web/sites/default/settings.local.php
  git checkout web/sites/default/settings.php
  sh -c "echo '\n// Development only configuration' >> web/sites/default/settings.local.php"
  sh -c "echo '\$settings['\''container_yamls'\''][] = DRUPAL_ROOT . '\''/sites/development.services.yml'\'';' >> web/sites/default/settings.local.php"
  sh -c "echo '\$config['\''system.logging'\'']['\''error_level'\''] = '\''verbose'\'';' >> web/sites/default/settings.local.php"
  sh -c "echo '\$config['\''system.performance'\'']['\''css'\'']['\''preprocess'\''] = FALSE;' >> web/sites/default/settings.local.php"
  sh -c "echo '\$config['\''system.performance'\'']['\''js'\'']['\''preprocess'\''] = FALSE;' >> web/sites/default/settings.local.php"
  sh -c "echo '\$settings['\''config_exclude_modules'\''] = [\n  '\''devel'\'',\n  '\''devel_php'\'',\n  '\''dblog'\'',\n];' >> web/sites/default/settings.local.php"
  sh -c "echo '\$settings['\''cache'\'']['\''bins'\'']['\''render'\''] = '\''cache.backend.null'\'';' >> web/sites/default/settings.local.php"
  sh -c "echo '\$settings['\''cache'\'']['\''bins'\'']['\''page'\''] = '\''cache.backend.null'\'';' >> web/sites/default/settings.local.php"
  sh -c "echo '\$settings['\''cache'\'']['\''bins'\'']['\''dynamic_page_cache'\''] = '\''cache.backend.null'\'';' >> web/sites/default/settings.local.php"
  sh -c "echo '\$settings['\''config_sync_directory'\''] = '\''config/default'\'';' >> web/sites/default/settings.local.php"
  echo -e "${BIGreen}\xE2\x9C\x94 settings.local.php folder created successfully ${Reset}"
  sleep 1
  echo -e " ${BIPurple} ████ Prepare development.services.yml file ████ ${Reset}"
  sleep 1
  echo -e 'parameters:' > web/sites/development.services.yml
  sh -c "echo '  http.response.debug_cacheability_headers: true' >> web/sites/development.services.yml"
  sh -c "echo '  twig.config:' >> web/sites/development.services.yml"
  sh -c "echo '    debug: true' >> web/sites/development.services.yml"
  sh -c "echo '    auto_reload: true' >> web/sites/development.services.yml"
  sh -c "echo '    cache: false' >> web/sites/development.services.yml"
  sh -c "echo 'services:' >> web/sites/development.services.yml"
  sh -c "echo '  cache.backend.null:' >> web/sites/development.services.yml"
  sh -c "echo '    class: Drupal\Core\Cache\NullBackendFactory' >> web/sites/development.services.yml"
  sleep 1
  echo -e "${BIGreen}\xE2\x9C\x94 development.services.yml folder updated successfully ${Reset}"
  sleep 1
  vendor/bin/drush cr
  vendor/bin/drush config-import -y
  vendor/bin/drush user-add-role administrator --uid=1
  sleep 1
  echo -e "${BICyan}██████ Installation process has been finished successfully ██████"
  sleep 1
  echo -e "██████ Use these credentials admin/admin or the following URL ██████"
  sleep 1
  vendor/bin/drush uli
else
  echo -e "${BICyan}██████████ See you again ██████████"
fi
}

_execute
