#!/bin/bash

. scripts/color.sh

echo -e " ${BIYellow} ██ 🎉 Booom! 🎉 This procedure takes less than 2 minutes, please be patient ... ${Reset}"
sleep 1
DEFAULT="n"
echo -e "Do you want to get a new clean copy from origin/master? (y/n) ${BIGreen} [Default : n] ${Reset} ${Yellow} \nBe aware all your changes will be discarded! do you want to continue? ${Reset}"
read CONFIRM
CONFIRM="${CONFIRM:-${DEFAULT}}"
if [[ $CONFIRM == "y" || $CONFIRM == "Y" || $CONFIRM == "yes" || $CONFIRM == "Yes" ]]
then
    git fetch && git checkout master && git reset --hard origin/master
    echo -e "${BIGreen}\xE2\x9C\x94 Pull from master completed successfully"
    sleep 1
    fi
composer install --no-interaction
sleep 1
echo -e "${BIGreen}\xE2\x9C\x94 composer install Done ████ ${Reset}"
sleep 1
vendor/bin/drush cr
vendor/bin/drush ci -y
vendor/bin/drush cr
vendor/bin/drush updatedb -y
vendor/bin/drush locale:update
vendor/bin/drush cr
echo -e "${BIGreen} ████████████ ${Reset}"
echo -e "${BIGreen}\xE2\x9C\x94 Go ahead ... 💪 ${Reset}"
echo -e "${BIGreen} ████████████ ${Reset}"

